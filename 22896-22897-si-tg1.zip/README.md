Projeto feito por:

José Francisco Fernandes - 22896   
Tierri Ferreira - 22897

Para ver todo projeto fazer `git clone` ao repositório seguinte.

Repositório git: https://github.com/TheBestPT/tg1_si

Link para os datasets no ficheiro: datasets.txt .